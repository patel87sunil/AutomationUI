**Task**

Import contacts from CSV file to salesforce.com

**Steps**
1. Read csv
2. Record "Login to salesforce" activity
3. Add a "For each row in datatable" activity
4. Record a sequence for inserting a contact into salesforce.
5. Insert the sequence into "for-each" sequence and replace the input data with data taken from the CSV file.

Before running the worklow be sure to set your salesforce username and password into "Login To Salesforce" Sequence.