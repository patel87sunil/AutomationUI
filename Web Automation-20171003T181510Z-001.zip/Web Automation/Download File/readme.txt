Task: 
Download a file from http://finance.yahoo.com/

Steps:
1. open http://finance.yahoo.com/
2. search for a company (MSFT) 
3. click  Historical Prices" 
4. specify the date range 
5. select "Weekly" 
6. click "Get Prices" 
7. download the file in the same folder as the workflow, with savedFile + timestamp as name.
8. close browser
