Task:

Use the folloing site http://69.166.140.73/zonelocatoreconomic/ to determin if 
one or many addresses are in an Economical Loss Zone.

Attention! : In Addresses.cvs put a business address not home address.

Steps:

1. Read CSV file

2. Open "http://69.166.140.73/zonelocatoreconomic/"

3. Click "Begin"

4. Click "Enter An Address"

5. Automatically enter the addresses 
   from the CVS file one by one in the address field.

6. Click "Locate Address"

7. Click "Location Correct"

8. Copy the information about the address which is as follows:
   "The address you provided is within Economic Loss Zone ..."
   in the same CSV file , next to the address you have been looking for.

9. Click "Search Again" 

10. Click "Locate Address" until there are no more addresses in CVS file.




